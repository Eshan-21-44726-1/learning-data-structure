#include<iostream>
using namespace std;
int main()
{
    int A[10] = {2, 5, 3, 8, 2, 6, 2, 1, 9, 2};
    int target;
    int count = 0;

    cout << "Enter an integer: ";
    cin >> target;

    for (int i = 0; i < 10; i++)
        {
        if (A[i] == target)
        {
            count++;
        }
    }

   cout << "The integer " << target << " occurs " << count << " times in the array." << endl;

    return 0;
}







