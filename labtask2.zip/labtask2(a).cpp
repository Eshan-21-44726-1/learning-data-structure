#include<iostream>
using namespace std;
int main()
{
    int i;
    int k;
    int a[5] = {10,20,30,40,50};
    int b[8] = {1,2,3,4,5,6,7,8};
    int c[13];
    for(i=0; i<5; i++)
    {
        c[i] = a[i];
    }
    k=i;
    for(i=0; i<8; i++)
    {
        c[k] = b[i];
        k++;
    }
        cout<<"Merged Array : "<<endl;
        for(i=0; i<k; i++)
            cout<<c[i]<<" "<<endl;
        cout<<endl;
        cout<<"Reversed Array : "<<endl;
        for(i=12; i>=0; i--)
        {
            cout<<c[i]<<" ";
            cout<<endl;
        }


    return 0;
}
